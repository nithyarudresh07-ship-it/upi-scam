# UPI Shield AI — Mobile-first Judge Edition

A colourful, responsive Streamlit prototype with a demo login and step-by-step flow:

1. Login / welcome screen
2. Home dashboard
3. AI message analyzer
4. Screenshot scanner (optional OCR via Tesseract)
5. Safety quiz
6. Safety Hub

## Run locally

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open the local URL printed in the terminal, usually `http://localhost:8501`.

## Notes

- Login is a demo-only session gate, not secure account authentication. Any name and syntactically valid email will work.
- The sample ML dataset is small and for demonstration only; risk labels are indicative, not guaranteed.
- Screenshot OCR requires Tesseract OCR installed separately. If OCR is unavailable, paste the screenshot text into AI Analyzer.
- This prototype is not connected to banks, UPI apps, or payment networks.
- The interface is designed to adapt to phone-width screens. For testing, resize the browser or open the local URL on a phone connected to the same Wi-Fi using your laptop's local network address.
