from pathlib import Path
import re, io
import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

BASE = Path(__file__).parent
st.set_page_config(page_title="UPI Shield AI", page_icon="🛡️", layout="wide", initial_sidebar_state="collapsed")
css = BASE / "styles.css"
if css.exists():
    st.markdown(f"<style>{css.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)

T = {
"English": {
"tag":"YOUR DIGITAL SAFETY COMPANION", "login_title":"Your money deserves a shield.", "login_sub":"Learn to spot payment scams before they catch you.", "name":"Your name", "email":"Email address", "continue":"Enter my safe space →", "demo":"Demo experience · No real bank account needed", "home":"Home", "analyzer":"AI Analyzer", "scanner":"Screenshot Scan", "quiz":"Safety Quiz", "tips":"Safety Hub", "welcome":"Welcome back", "tagline":"Detect. Understand. Prevent.", "intro":"A smarter way to pause, check, and stay safe with digital payments.", "analyze":"Analyze a message", "scan":"Scan a screenshot", "learn":"Test your scam radar", "read":"Explore safety tips", "quick":"Your safety toolkit", "workflow":"YOUR SAFETY FLOW", "step1":"Paste a message", "step2":"Understand warning signs", "step3":"Choose a safer action", "message_title":"Does this message feel suspicious?", "message_help":"Paste an SMS, WhatsApp message, or payment request below.", "sample":"Try a sample message", "message":"Message text", "analyze_btn":"Analyze message", "empty":"Please enter a message first.", "result":"Your safety check", "why":"Why it was flagged", "tips_title":"What to do next", "scan_title":"Give a screenshot a safety check", "scan_help":"Upload a screenshot of an SMS or chat. We'll try to read the text and check common warning signs.", "upload":"Upload screenshot", "ocr_btn":"Read & check screenshot", "ocr_missing":"OCR needs Tesseract installed on your computer. You can still paste the text in AI Analyzer.", "quiz_title":"Train your scam radar", "quiz_sub":"Four everyday situations. Choose the safest response.", "check":"Check answer", "next":"Next question →", "finish":"Finish quiz", "restart":"Try quiz again", "correct":"Correct! Great safety instinct.", "incorrect":"Not quite. Here's the safer choice:", "score":"Your result", "safety_title":"Your everyday safety hub", "safety_sub":"Small habits can protect your money and personal information.", "profile":"Your session", "logout":"Log out", "risk":"Risk level", "high":"HIGH RISK", "medium":"CAUTION", "low":"LOW SIGNALS", "notice":"Prototype notice: This is an educational demo, not connected to banks or UPI networks. A low-risk result does not prove a message is genuine.", "language":"Language", "back":"← Back", "nextpage":"Continue →", "start":"Start with a message", "home_btn":"Back to home", "sign_in":"Welcome to UPI Shield AI"
},
"ಕನ್ನಡ": {
"tag":"ನಿಮ್ಮ ಡಿಜಿಟಲ್ ಸುರಕ್ಷತಾ ಸಂಗಾತಿ", "login_title":"ನಿಮ್ಮ ಹಣಕ್ಕೆ ಸುರಕ್ಷತಾ ಕವಚ.", "login_sub":"ಡಿಜಿಟಲ್ ಪಾವತಿ ವಂಚನೆಗಳನ್ನು ಗುರುತಿಸಲು ಕಲಿಯಿರಿ.", "name":"ನಿಮ್ಮ ಹೆಸರು", "email":"ಇಮೇಲ್ ವಿಳಾಸ", "continue":"ಸುರಕ್ಷಿತವಾಗಿ ಮುಂದುವರಿಯಿರಿ →", "demo":"ಡೆಮೋ ಅನುಭವ · ನಿಜವಾದ ಬ್ಯಾಂಕ್ ಖಾತೆ ಅಗತ್ಯವಿಲ್ಲ", "home":"ಮುಖಪುಟ", "analyzer":"AI ವಿಶ್ಲೇಷಣೆ", "scanner":"ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಸ್ಕ್ಯಾನ್", "quiz":"ಸುರಕ್ಷತಾ ಕ್ವಿಜ್", "tips":"ಸುರಕ್ಷತಾ ಸಲಹೆಗಳು", "welcome":"ಮತ್ತೆ ಸ್ವಾಗತ", "tagline":"ಪತ್ತೆಹಚ್ಚಿ. ಅರ್ಥಮಾಡಿಕೊಳ್ಳಿ. ತಡೆಯಿರಿ.", "intro":"ಡಿಜಿಟಲ್ ಪಾವತಿಗಳಲ್ಲಿ ನಿಲ್ಲಿಸಿ, ಪರಿಶೀಲಿಸಿ, ಸುರಕ್ಷಿತವಾಗಿರಿ.", "analyze":"ಸಂದೇಶವನ್ನು ಪರಿಶೀಲಿಸಿ", "scan":"ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಪರಿಶೀಲಿಸಿ", "learn":"ನಿಮ್ಮ ಜಾಗೃತಿಯನ್ನು ಪರೀಕ್ಷಿಸಿ", "read":"ಸುರಕ್ಷತಾ ಸಲಹೆಗಳನ್ನು ನೋಡಿ", "quick":"ನಿಮ್ಮ ಸುರಕ್ಷತಾ ಸಾಧನಗಳು", "workflow":"ನಿಮ್ಮ ಸುರಕ್ಷತಾ ಹಂತಗಳು", "step1":"ಸಂದೇಶ ಅಂಟಿಸಿ", "step2":"ಎಚ್ಚರಿಕೆಗಳನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳಿ", "step3":"ಸುರಕ್ಷಿತ ಕ್ರಮ ಆರಿಸಿ", "message_title":"ಈ ಸಂದೇಶ ಅನುಮಾನಾಸ್ಪದವೇ?", "message_help":"SMS, WhatsApp ಸಂದೇಶ ಅಥವಾ ಪಾವತಿ ವಿನಂತಿಯನ್ನು ಅಂಟಿಸಿ.", "sample":"ಉದಾಹರಣೆ ಸಂದೇಶ ಪ್ರಯತ್ನಿಸಿ", "message":"ಸಂದೇಶದ ಪಠ್ಯ", "analyze_btn":"ಸಂದೇಶ ಪರಿಶೀಲಿಸಿ", "empty":"ಮೊದಲು ಸಂದೇಶವನ್ನು ನಮೂದಿಸಿ.", "result":"ಸುರಕ್ಷತಾ ಪರಿಶೀಲನೆ", "why":"ಎಚ್ಚರಿಕೆ ಗುರುತಿಸಿದ ಕಾರಣ", "tips_title":"ಮುಂದೆ ಏನು ಮಾಡಬೇಕು", "scan_title":"ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಪರಿಶೀಲನೆ", "scan_help":"SMS ಅಥವಾ ಚಾಟ್‌ನ ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.", "upload":"ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ", "ocr_btn":"ಪಠ್ಯ ಓದಿ ಪರಿಶೀಲಿಸಿ", "ocr_missing":"OCR ಗೆ ನಿಮ್ಮ ಕಂಪ್ಯೂಟರ್‌ನಲ್ಲಿ Tesseract ಅಗತ್ಯವಿದೆ. ಬದಲಿಗೆ AI ವಿಶ್ಲೇಷಣೆಯಲ್ಲಿ ಪಠ್ಯ ಅಂಟಿಸಬಹುದು.", "quiz_title":"ವಂಚನೆ ಗುರುತಿಸುವ ಅಭ್ಯಾಸ", "quiz_sub":"ನಾಲ್ಕು ದೈನಂದಿನ ಸಂದರ್ಭಗಳು. ಸುರಕ್ಷಿತ ಉತ್ತರ ಆಯ್ಕೆಮಾಡಿ.", "check":"ಉತ್ತರ ಪರಿಶೀಲಿಸಿ", "next":"ಮುಂದಿನ ಪ್ರಶ್ನೆ →", "finish":"ಕ್ವಿಜ್ ಮುಗಿಸಿ", "restart":"ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ", "correct":"ಸರಿಯಾಗಿದೆ! ಉತ್ತಮ ಸುರಕ್ಷತಾ ನಿರ್ಧಾರ.", "incorrect":"ಇನ್ನೂ ಉತ್ತಮ ಉತ್ತರ ಇದೆ:", "score":"ನಿಮ್ಮ ಫಲಿತಾಂಶ", "safety_title":"ದೈನಂದಿನ ಸುರಕ್ಷತಾ ಕೇಂದ್ರ", "safety_sub":"ಸಣ್ಣ ಅಭ್ಯಾಸಗಳು ನಿಮ್ಮ ಹಣ ಮತ್ತು ಮಾಹಿತಿಯನ್ನು ರಕ್ಷಿಸುತ್ತವೆ.", "profile":"ನಿಮ್ಮ ಸೆಷನ್", "logout":"ಲಾಗ್ ಔಟ್", "risk":"ಅಪಾಯದ ಮಟ್ಟ", "high":"ಹೆಚ್ಚಿನ ಅಪಾಯ", "medium":"ಎಚ್ಚರಿಕೆ", "low":"ಕಡಿಮೆ ಸೂಚನೆಗಳು", "notice":"ಡೆಮೋ ಸೂಚನೆ: ಇದು ಶಿಕ್ಷಣಕ್ಕಾಗಿ ಮಾತ್ರ; ಬ್ಯಾಂಕ್ ಅಥವಾ UPI ನೆಟ್‌ವರ್ಕ್‌ಗೆ ಸಂಪರ್ಕಗೊಂಡಿಲ್ಲ. ಕಡಿಮೆ ಅಪಾಯ ಎಂದರೆ ಸಂದೇಶ ನಿಜವೆಂದು ಖಾತರಿಯಲ್ಲ.", "language":"ಭಾಷೆ", "back":"← ಹಿಂದೆ", "nextpage":"ಮುಂದುವರಿಯಿರಿ →", "start":"ಸಂದೇಶದಿಂದ ಪ್ರಾರಂಭಿಸಿ", "home_btn":"ಮುಖಪುಟಕ್ಕೆ ಹಿಂತಿರುಗಿ", "sign_in":"UPI Shield AI ಗೆ ಸ್ವಾಗತ"
}}

lang = st.sidebar.selectbox("Language / ಭಾಷೆ", ["English", "ಕನ್ನಡ"], key="language_choice")
t = T[lang]; kn = lang == "ಕನ್ನಡ"
if "logged_in" not in st.session_state: st.session_state.logged_in = False
if "page" not in st.session_state: st.session_state.page = "Login"
if "user_name" not in st.session_state: st.session_state.user_name = ""
if "user_email" not in st.session_state: st.session_state.user_email = ""
if "last_result" not in st.session_state: st.session_state.last_result = None
if "quiz_index" not in st.session_state: st.session_state.quiz_index = 0
if "quiz_score" not in st.session_state: st.session_state.quiz_score = 0
if "quiz_checked" not in st.session_state: st.session_state.quiz_checked = False

@st.cache_resource
def load_model():
    df = pd.read_csv(BASE / "data" / "training_messages.csv")
    model = Pipeline([("tfidf", TfidfVectorizer(ngram_range=(1,2), lowercase=True, strip_accents="unicode")), ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))])
    model.fit(df["message"].astype(str), df["label"].astype(str))
    return model

INDICATORS = [
("Urgency or threat", r"\b(block(ed)?|suspend(ed)?|urgent|immediately|today|within \d+ hours|last warning|account will)\b"),
("Unexpected prize or reward", r"\b(won|winner|lottery|prize|reward|cashback|gift|congratulations)\b"),
("PIN, OTP or password request", r"\b(upi pin|pin|otp|one.time password|password|cvv)\b"),
("Link or click request", r"\b(click|tap|verify|claim|open link|link below|https?://|www\.)\b"),
("Payment to receive money", r"\b(pay|send|transfer)\b.{0,35}\b(receive|refund|prize|reward|cashback|claim)\b"),
("Bank / KYC impersonation language", r"\b(bank support|customer care|kyc|account verification|official support)\b")]

def assess(message):
    model = load_model(); low = message.lower(); found = [label for label, pat in INDICATORS if re.search(pat, low, re.I)]
    prediction = model.predict([message])[0]
    high = any(x in low for x in ["upi pin", "otp", "password", "cvv", "pay to receive", "pay to claim"])
    risk = "HIGH" if high or len(found) >= 3 else "MEDIUM" if found or prediction == "scam" else "LOW"
    explanations = []
    lookup = {
      "Urgency or threat":"The message pressures you to act quickly or threatens account restrictions.",
      "Unexpected prize or reward":"It mentions an unexpected prize, reward, or cash benefit.",
      "PIN, OTP or password request":"It refers to sensitive credentials. Never share a PIN or OTP.",
      "Link or click request":"It encourages clicking a link. Verify the destination independently.",
      "Payment to receive money":"It may ask you to pay to receive a refund, prize, or reward.",
      "Bank / KYC impersonation language":"It uses bank, KYC, or support language. Verify through the official app."
    }
    explanations = [lookup[x] for x in found] or ["No common warning pattern was detected. This does not prove the message is genuine."]
    return {"risk":risk, "prediction":prediction, "indicators":found, "explanations":explanations}

TIPS = [
("🔐", "Protect your UPI PIN", "Never share your UPI PIN or OTP. You do not need a PIN to receive money."),
("🔗", "Pause before tapping", "Avoid unexpected links. Open your bank or payment app directly instead."),
("🎁", "Question surprise rewards", "A prize that asks for an upfront fee is a strong warning sign."),
("🧾", "Verify in your own app", "Screenshots can be edited. Confirm payments in your official app or bank account."),
("☎️", "Use official contacts", "Do not trust a number sent by an unknown caller. Find contact details yourself."),
("🚨", "Act quickly after suspected fraud", "Contact your bank through official channels and report suspected cyber fraud.")]
QUIZ = [
 {"q":"A caller says you must enter your UPI PIN to receive a refund. What should you do?", "opts":["Enter the PIN", "Never share the PIN; verify in the official app", "Send your OTP"], "a":1, "lesson":"A UPI PIN authorizes payments. You do not need to enter it just to receive money."},
 {"q":"A message says you won ₹10,000 but must pay a fee. What is safest?", "opts":["Pay quickly", "Forward it", "Do not pay; verify independently"], "a":2, "lesson":"Unexpected prizes that require upfront payment are a common scam warning sign."},
 {"q":"A bank link asks you to update KYC immediately. What should you do?", "opts":["Open the link", "Open the bank's official app yourself", "Share your OTP"], "a":1, "lesson":"Avoid unexpected links for banking services. Open the official app yourself."},
 {"q":"A buyer shows a payment screenshot. How do you confirm payment?", "opts":["Trust the screenshot", "Hand over the item", "Check your own official payment app"], "a":2, "lesson":"Screenshots can be edited. Confirm the transaction in your own app."}]

def go(page):
    st.session_state.page = page
    st.rerun()

def page_header(kicker, title, subtitle, emoji="✨"):
    st.markdown(f'<div class="page-heading"><div class="page-kicker">{emoji} {kicker}</div><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)

def top_progress(current):
    order = ["Home", "Analyzer", "Scanner", "Quiz", "Safety Hub"]
    if current in order:
        idx = order.index(current)+1
        st.markdown(f'<div class="progress-wrap"><div class="progress-label"><span>YOUR SAFETY JOURNEY</span><span>STEP {idx} OF 5</span></div><div class="progress-track"><div class="progress-fill" style="width:{idx*20}%"></div></div></div>', unsafe_allow_html=True)

def bottom_nav(current):
    st.markdown('<div class="mobile-nav-label">QUICK NAVIGATION</div>', unsafe_allow_html=True)
    cols = st.columns(5)
    nav = [("🏡",t["home"],"Home"),("🛡️",t["analyzer"],"Analyzer"),("📸",t["scanner"],"Scanner"),("🎯",t["quiz"],"Quiz"),("💡",t["tips"],"Safety Hub")]
    for col,(ico,label,key) in zip(cols,nav):
        with col:
            if st.button(f"{ico}\n{label}", key=f"nav_{key}", use_container_width=True, type="primary" if current==key else "secondary"):
                go(key)

# LOGIN SCREEN
if not st.session_state.logged_in:
    st.markdown('<div class="login-shell">', unsafe_allow_html=True)
    left, right = st.columns([1.1, .9], gap="large")
    with left:
        st.markdown(f'''<div class="login-hero"><div class="brand-lockup"><span class="brand-icon">🛡️</span><span>UPI Shield <b>AI</b></span></div><div class="pill-bright">✦ {t['tag']}</div><h1>{t['login_title']}</h1><p>{t['login_sub']}</p><div class="login-benefits"><span>🧠 AI message checks</span><span>📱 Screenshot scanner</span><span>🎯 Fun safety quiz</span></div><div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="phone-art"><div class="phone-speaker"></div><div class="phone-screen"><div class="mini-status">● SAFE PAYMENT</div><div class="mini-shield">🛡️</div><div class="mini-check">✓</div><b>Stay scam-smart</b><small>Your safety comes first</small><div class="mini-bars"><i></i><i></i><i></i></div></div></div><div class="float-bubble bubble-one">🔒</div><div class="float-bubble bubble-two">₹</div><div class="float-bubble bubble-three">✨</div></div><div class="login-footnote">{t['demo']}</div></div>''', unsafe_allow_html=True)
    with right:
        st.markdown(f'<div class="login-form-card"><div class="form-eyebrow">{t["sign_in"]}</div><h2>{"Let’s make digital payments safer." if not kn else "ಡಿಜಿಟಲ್ ಪಾವತಿಯನ್ನು ಸುರಕ್ಷಿತಗೊಳಿಸೋಣ."}</h2><p>{"Enter your details to explore your personal safety dashboard." if not kn else "ನಿಮ್ಮ ಸುರಕ್ಷತಾ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ನೋಡಲು ವಿವರಗಳನ್ನು ನಮೂದಿಸಿ."}</p>', unsafe_allow_html=True)
        with st.form("login_form"):
            name = st.text_input(t["name"], placeholder="e.g. Nithya")
            email = st.text_input(t["email"], placeholder="you@example.com")
            submitted = st.form_submit_button(t["continue"], use_container_width=True, type="primary")
            if submitted:
                if not name.strip() or not email.strip() or "@" not in email:
                    st.error("Please enter your name and a valid email address." if not kn else "ದಯವಿಟ್ಟು ಹೆಸರು ಮತ್ತು ಸರಿಯಾದ ಇಮೇಲ್ ನಮೂದಿಸಿ.")
                else:
                    st.session_state.user_name=name.strip(); st.session_state.user_email=email.strip(); st.session_state.logged_in=True; st.session_state.page="Home"; st.rerun()
        st.markdown('<div class="privacy-note">🔐 Demo only — details stay in this browser session. This is not a real account login.</div></div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
    st.stop()

# Header + sign out
head1, head2 = st.columns([4,1])
with head1:
    st.markdown('<div class="mini-brand"><span>🛡️</span> UPI Shield <b>AI</b><small>YOUR DIGITAL SAFETY COMPANION</small></div>', unsafe_allow_html=True)
with head2:
    if st.button("↪ " + t["logout"], key="logout", use_container_width=True):
        st.session_state.logged_in=False; st.session_state.page="Login"; st.rerun()
current=st.session_state.page
if current not in ["Home","Analyzer","Scanner","Quiz","Safety Hub"]: current="Home"
top_progress(current)

if current == "Home":
    page_header("WELCOME TO YOUR SAFE SPACE", f'{t["welcome"]}, {st.session_state.user_name} 👋', t["intro"], "🌈")
    st.markdown(f'''<div class="dashboard-hero"><div class="hero-copy"><div class="hero-label">🛡️ DIGITAL CONFIDENCE, EVERY DAY</div><h2>{t['tagline']}</h2><p>{"Small checks. Smarter choices. Stronger protection." if not kn else "ಸಣ್ಣ ಪರಿಶೀಲನೆ. ಉತ್ತಮ ಆಯ್ಕೆ. ಬಲವಾದ ರಕ್ಷಣೆ."}</p><div class="hero-chips"><span>✦ AI-assisted</span><span>✦ English + ಕನ್ನಡ</span><span>✦ Learn by doing</span></div></div><div class="dashboard-art"><div class="big-shield">🛡️</div><div class="art-orbit"></div><div class="art-coin coin-a">₹</div><div class="art-coin coin-b">✓</div><div class="art-spark">✦</div></div></div>''', unsafe_allow_html=True)
    st.markdown(f'<div class="section-title"><div><span>✦</span> {t["quick"]}</div><small>CHOOSE YOUR NEXT STEP</small></div>', unsafe_allow_html=True)
    cards = [
      ("🧠","card-purple",t["analyze"],"Spot suspicious links, urgency and requests for PIN or OTP.","Analyzer","01"),
      ("📸","card-pink",t["scan"],"Read a message screenshot and check warning signs.","Scanner","02"),
      ("🎯","card-teal",t["learn"],"Practice realistic situations and build safer habits.","Quiz","03"),
      ("💡","card-orange",t["read"],"Explore simple actions that help protect your money.","Safety Hub","04")]
    cols=st.columns(2, gap="medium")
    for i,(ico,cls,title,desc,target,num) in enumerate(cards):
        with cols[i%2]:
            st.markdown(f'<div class="feature-card {cls}"><div class="feature-top"><span class="feature-icon">{ico}</span><span class="feature-number">{num}</span></div><h3>{title}</h3><p>{desc}</p></div>', unsafe_allow_html=True)
            if st.button("Open feature →", key=f"open_{target}", use_container_width=True): go(target)
    st.markdown(f'<div class="workflow-banner"><div class="workflow-heading">{t["workflow"]}</div><div class="workflow-steps"><span><b>1</b>{t["step1"]}</span><i>→</i><span><b>2</b>{t["step2"]}</span><i>→</i><span><b>3</b>{t["step3"]}</span></div></div>', unsafe_allow_html=True)
    st.caption(t["notice"])

elif current == "Analyzer":
    page_header("AI MESSAGE CHECK", t["message_title"], t["message_help"], "🧠")
    examples={"Choose a sample":"", "Fake account-block warning":"URGENT: Your bank account will be blocked today. Click http://example.invalid and enter your OTP to verify.", "Fake prize message":"Congratulations! You won ₹10,000. Pay ₹100 to claim your reward using this link.", "Payment reminder":"Reminder: Your electricity bill is due tomorrow. Please check the bill in your official provider app."}
    selected=st.selectbox(t["sample"], list(examples.keys()))
    message=st.text_area(t["message"], value=examples[selected], height=150, placeholder="Paste the message here…" if not kn else "ಸಂದೇಶವನ್ನು ಇಲ್ಲಿ ಅಂಟಿಸಿ…", key="analyzer_message")
    if st.button("✨ " + t["analyze_btn"], type="primary", use_container_width=True):
        if not message.strip(): st.warning(t["empty"])
        else: st.session_state.last_result=assess(message)
    if st.session_state.last_result:
        r=st.session_state.last_result; cls={"HIGH":"risk-high","MEDIUM":"risk-medium","LOW":"risk-low"}[r["risk"]]; label={"HIGH":t["high"],"MEDIUM":t["medium"],"LOW":t["low"]}[r["risk"]]
        st.markdown(f'<div class="result-card {cls}"><div class="result-top"><span>🛡️ {t["result"]}</span><span class="risk-badge">{label}</span></div><div class="risk-word">{r["risk"]}</div><p>AI demo prediction: <b>{r["prediction"].upper()}</b> · pattern-based indicators included</p></div>', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title"><div>🔎 {t["why"]}</div></div>', unsafe_allow_html=True)
        for x in r["explanations"]: st.markdown(f'<div class="explanation-row"><span>✦</span>{x}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="section-title"><div>💜 {t["tips_title"]}</div></div>', unsafe_allow_html=True)
        for icon,title,desc in TIPS[:4]: st.markdown(f'<div class="tip-row"><span>{icon}</span><div><b>{title}</b><p>{desc}</p></div></div>', unsafe_allow_html=True)
        st.caption("A low risk score does not prove a message is safe. Verify independently.")
    c1,c2=st.columns(2)
    with c1:
        if st.button(t["back"], use_container_width=True): go("Home")
    with c2:
        if st.button(t["nextpage"], use_container_width=True): go("Scanner")

elif current == "Scanner":
    page_header("SCREENSHOT SAFETY", t["scan_title"], t["scan_help"], "📸")
    st.markdown('<div class="upload-promo"><div class="upload-emoji">📱</div><h3>Drop it in. Check before you click.</h3><p>Upload a clear screenshot of a suspicious SMS or chat.</p><div class="upload-tags"><span>PNG</span><span>JPG</span><span>JPEG</span></div></div>', unsafe_allow_html=True)
    uploaded=st.file_uploader(t["upload"], type=["png","jpg","jpeg"])
    if uploaded:
        st.image(uploaded, caption="Screenshot preview", use_container_width=True)
        if st.button("🔍 " + t["ocr_btn"], type="primary", use_container_width=True):
            try:
                from PIL import Image
                import pytesseract
                image=Image.open(io.BytesIO(uploaded.getvalue()))
                extracted=pytesseract.image_to_string(image)
                st.text_area("Extracted text", value=extracted, height=130)
                if extracted.strip():
                    r=assess(extracted); label={"HIGH":t["high"],"MEDIUM":t["medium"],"LOW":t["low"]}[r["risk"]]
                    st.markdown(f'<div class="result-card risk-{r["risk"].lower()}"><div class="result-top"><span>🛡️ Scan result</span><span class="risk-badge">{label}</span></div><div class="risk-word">{r["risk"]}</div></div>', unsafe_allow_html=True)
                    for x in r["explanations"]: st.markdown(f'<div class="explanation-row"><span>✦</span>{x}</div>', unsafe_allow_html=True)
                else: st.warning("No readable text found. Try a clearer image.")
            except Exception:
                st.warning(t["ocr_missing"])
    else:
        st.info(t["ocr_missing"])
    c1,c2=st.columns(2)
    with c1:
        if st.button(t["back"], use_container_width=True): go("Analyzer")
    with c2:
        if st.button(t["nextpage"], use_container_width=True): go("Quiz")

elif current == "Quiz":
    page_header("LEARN BY DOING", t["quiz_title"], t["quiz_sub"], "🎯")
    idx=st.session_state.quiz_index
    if idx >= len(QUIZ):
        score=st.session_state.quiz_score
        st.markdown(f'<div class="score-card"><div class="score-emoji">{"🏆" if score>=3 else "🌱"}</div><div class="score-caption">{t["score"]}</div><div class="score-number">{score}<span> / {len(QUIZ)}</span></div><p>{"Great work! Keep practicing safe payment habits." if score>=3 else "Good start! Review the safety tips and try again."}</p></div>', unsafe_allow_html=True)
        if st.button(t["restart"], type="primary", use_container_width=True): st.session_state.quiz_index=0; st.session_state.quiz_score=0; st.session_state.quiz_checked=False; st.rerun()
        if st.button(t["nextpage"], use_container_width=True): go("Safety Hub")
    else:
        q=QUIZ[idx]
        st.markdown(f'<div class="quiz-progress"><div><b>QUESTION {idx+1}</b><span>{idx+1} of {len(QUIZ)}</span></div><div class="progress-track"><div class="progress-fill" style="width:{(idx+1)/len(QUIZ)*100}%"></div></div></div>', unsafe_allow_html=True)
        st.markdown(f'<div class="question-card"><div class="question-icon">❓</div><h3>{q["q"]}</h3></div>', unsafe_allow_html=True)
        answer=st.radio("Choose one answer", q["opts"], key=f"quiz_answer_{idx}", label_visibility="collapsed")
        if not st.session_state.quiz_checked:
            if st.button(t["check"], type="primary", use_container_width=True):
                if q["opts"].index(answer)==q["a"]: st.session_state.quiz_score+=1; st.session_state.quiz_feedback=t["correct"]
                else: st.session_state.quiz_feedback=t["incorrect"]+" "+q["opts"][q["a"]]
                st.session_state.quiz_checked=True; st.rerun()
        else:
            st.markdown(f'<div class="feedback-card">💡 {st.session_state.quiz_feedback}<p>{q["lesson"]}</p></div>', unsafe_allow_html=True)
            label=t["finish"] if idx==len(QUIZ)-1 else t["next"]
            if st.button(label, type="primary", use_container_width=True): st.session_state.quiz_index+=1; st.session_state.quiz_checked=False; st.rerun()
    if st.button(t["back"], use_container_width=True): go("Scanner")

elif current == "Safety Hub":
    page_header("SAFETY THAT STICKS", t["safety_title"], t["safety_sub"], "💡")
    for i,(icon,title,desc) in enumerate(TIPS):
        st.markdown(f'<div class="safety-tip-card tip-color-{i%4}"><div class="safety-tip-icon">{icon}</div><div><h3>{title if not kn else ["ನಿಮ್ಮ UPI PIN ರಕ್ಷಿಸಿ","ಲಿಂಕ್ ಕ್ಲಿಕ್ ಮಾಡುವ ಮೊದಲು ನಿಲ್ಲಿಸಿ","ಅನಿರೀಕ್ಷಿತ ಬಹುಮಾನಗಳನ್ನು ಪ್ರಶ್ನಿಸಿ","ನಿಮ್ಮ ಆ್ಯಪ್‌ನಲ್ಲಿ ಪರಿಶೀಲಿಸಿ","ಅಧಿಕೃತ ಸಂಪರ್ಕ ಬಳಸಿ","ವಂಚನೆ ಶಂಕೆಯಾದರೆ ತಕ್ಷಣ ಕ್ರಮ ಕೈಗೊಳ್ಳಿ"][i]}</h3><p>{desc if not kn else ["ನಿಮ್ಮ UPI PIN ಅಥವಾ OTP ಯಾರೊಂದಿಗೂ ಹಂಚಿಕೊಳ್ಳಬೇಡಿ. ಹಣ ಸ್ವೀಕರಿಸಲು PIN ಅಗತ್ಯವಿಲ್ಲ.","ಅನಿರೀಕ್ಷಿತ ಲಿಂಕ್‌ಗಳನ್ನು ತಪ್ಪಿಸಿ. ಬ್ಯಾಂಕ್ ಆ್ಯಪ್ ಅನ್ನು ನೇರವಾಗಿ ತೆರೆಯಿರಿ.","ಮುಂಗಡ ಶುಲ್ಕ ಕೇಳುವ ಬಹುಮಾನ ವಂಚನೆಯ ಸೂಚನೆಯಾಗಿರಬಹುದು.","ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಬದಲಾಯಿಸಬಹುದು. ನಿಮ್ಮ ಅಧಿಕೃತ ಆ್ಯಪ್‌ನಲ್ಲಿ ಪಾವತಿ ಪರಿಶೀಲಿಸಿ.","ಅಪರಿಚಿತರು ನೀಡಿದ ಸಂಖ್ಯೆಯನ್ನು ನಂಬಬೇಡಿ. ಅಧಿಕೃತ ಸಂಪರ್ಕವನ್ನು ನೀವೇ ಹುಡುಕಿ.","ಅಧಿಕೃತ ಮಾರ್ಗದಲ್ಲಿ ಬ್ಯಾಂಕ್ ಸಂಪರ್ಕಿಸಿ ಮತ್ತು ವಂಚನೆಯನ್ನು ವರದಿ ಮಾಡಿ."][i]}</p></div></div>', unsafe_allow_html=True)
    st.markdown(f'<div class="emergency-card"><div>🚨</div><section><h3>{"Think you were scammed?" if not kn else "ವಂಚನೆ ಆಗಿದೆ ಎಂದು ಭಾವಿಸುತ್ತೀರಾ?"}</h3><p>{"Contact your bank immediately using official contact details and report through official cybercrime channels." if not kn else "ಅಧಿಕೃತ ಸಂಪರ್ಕ ವಿವರಗಳ ಮೂಲಕ ತಕ್ಷಣ ಬ್ಯಾಂಕ್ ಸಂಪರ್ಕಿಸಿ ಮತ್ತು ಅಧಿಕೃತ ಸೈಬರ್ ಅಪರಾಧ ಮಾರ್ಗದಲ್ಲಿ ವರದಿ ಮಾಡಿ."}</p></section></div>', unsafe_allow_html=True)
    if st.button(t["home_btn"], type="primary", use_container_width=True): go("Home")

st.markdown('<div class="footer-note">🛡️ UPI Shield AI · Learn to pause, verify, and protect · Demo project for digital safety awareness</div>', unsafe_allow_html=True)
bottom_nav(current)
